#include "QtWidgetsApplication3.h"


QtWidgetsApplication3::QtWidgetsApplication3(QWidget *parent)
    : QWidget(parent)
{
    ui.setupUi(this);
}
void QtWidgetsApplication3::run_btn_1()
{
    blue_count++;
    blue_sig = 1;
    red_sig = 0;
    total_count = blue_count + red_count;
    QString str_blue = QString::number(blue_count);
    QString str_total = QString::number(total_count);
    ui.blue_label->setText(str_blue);
    ui.total_label->setText(str_total);
}

void QtWidgetsApplication3::run_btn_2()
{
    red_count++;
    blue_sig = 0;
    red_sig = 1;
    total_count = blue_count + red_count;
    QString str_red = QString::number(red_count);
    QString str_total = QString::number(total_count);
    ui.red_label->setText(str_red);
    ui.total_label->setText(str_total);
}
void QtWidgetsApplication3::run_btn_3()
{
    if (blue_sig == 1) {
        blue_count--;
    }
    else red_count--;

    total_count = blue_count + red_count;
    QString str_blue = QString::number(blue_count);
    QString str_red = QString::number(red_count);
    QString str_total = QString::number(total_count);
    ui.red_label->setText(str_red);
    ui.blue_label->setText(str_blue);
    ui.total_label->setText(str_total);
}
void QtWidgetsApplication3::run_btn_reset()
{
    total_count = 0;
    red_count = 0;
    blue_count = 0;
    ui.red_label->setText("00");
    ui.blue_label->setText("00");
    ui.total_label->setText("00");
}