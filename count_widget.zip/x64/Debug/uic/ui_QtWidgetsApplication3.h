/********************************************************************************
** Form generated from reading UI file 'QtWidgetsApplication3.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_QTWIDGETSAPPLICATION3_H
#define UI_QTWIDGETSAPPLICATION3_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_QtWidgetsApplication3Class
{
public:
    QWidget *verticalLayoutWidget;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_2;
    QLabel *total_label;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label;
    QLabel *blue_label;
    QLabel *label_4;
    QLabel *red_label;
    QHBoxLayout *horizontalLayout;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;

    void setupUi(QWidget *QtWidgetsApplication3Class)
    {
        if (QtWidgetsApplication3Class->objectName().isEmpty())
            QtWidgetsApplication3Class->setObjectName(QString::fromUtf8("QtWidgetsApplication3Class"));
        QtWidgetsApplication3Class->resize(600, 400);
        verticalLayoutWidget = new QWidget(QtWidgetsApplication3Class);
        verticalLayoutWidget->setObjectName(QString::fromUtf8("verticalLayoutWidget"));
        verticalLayoutWidget->setGeometry(QRect(170, 91, 281, 131));
        verticalLayout = new QVBoxLayout(verticalLayoutWidget);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        label_2 = new QLabel(verticalLayoutWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setAlignment(Qt::AlignCenter);

        horizontalLayout_3->addWidget(label_2);

        total_label = new QLabel(verticalLayoutWidget);
        total_label->setObjectName(QString::fromUtf8("total_label"));

        horizontalLayout_3->addWidget(total_label);


        verticalLayout->addLayout(horizontalLayout_3);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        label = new QLabel(verticalLayoutWidget);
        label->setObjectName(QString::fromUtf8("label"));
        QFont font;
        font.setPointSize(15);
        label->setFont(font);
        label->setLayoutDirection(Qt::LeftToRight);
        label->setAlignment(Qt::AlignCenter);

        horizontalLayout_2->addWidget(label);

        blue_label = new QLabel(verticalLayoutWidget);
        blue_label->setObjectName(QString::fromUtf8("blue_label"));
        blue_label->setFont(font);
        blue_label->setLayoutDirection(Qt::LeftToRight);
        blue_label->setAlignment(Qt::AlignCenter);

        horizontalLayout_2->addWidget(blue_label);

        label_4 = new QLabel(verticalLayoutWidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setFont(font);
        label_4->setLayoutDirection(Qt::LeftToRight);
        label_4->setAlignment(Qt::AlignCenter);

        horizontalLayout_2->addWidget(label_4);

        red_label = new QLabel(verticalLayoutWidget);
        red_label->setObjectName(QString::fromUtf8("red_label"));
        red_label->setFont(font);
        red_label->setLayoutDirection(Qt::LeftToRight);
        red_label->setAlignment(Qt::AlignCenter);

        horizontalLayout_2->addWidget(red_label);


        verticalLayout->addLayout(horizontalLayout_2);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        pushButton = new QPushButton(verticalLayoutWidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));

        horizontalLayout->addWidget(pushButton);

        pushButton_2 = new QPushButton(verticalLayoutWidget);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));

        horizontalLayout->addWidget(pushButton_2);

        pushButton_3 = new QPushButton(verticalLayoutWidget);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));

        horizontalLayout->addWidget(pushButton_3);


        verticalLayout->addLayout(horizontalLayout);

        pushButton_4 = new QPushButton(verticalLayoutWidget);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));

        verticalLayout->addWidget(pushButton_4);


        retranslateUi(QtWidgetsApplication3Class);
        QObject::connect(pushButton, SIGNAL(clicked()), QtWidgetsApplication3Class, SLOT(run_btn_1()));
        QObject::connect(pushButton_2, SIGNAL(clicked()), QtWidgetsApplication3Class, SLOT(run_btn_2()));
        QObject::connect(pushButton_3, SIGNAL(clicked()), QtWidgetsApplication3Class, SLOT(run_btn_3()));
        QObject::connect(pushButton_4, SIGNAL(clicked()), QtWidgetsApplication3Class, SLOT(run_btn_reset()));

        QMetaObject::connectSlotsByName(QtWidgetsApplication3Class);
    } // setupUi

    void retranslateUi(QWidget *QtWidgetsApplication3Class)
    {
        QtWidgetsApplication3Class->setWindowTitle(QCoreApplication::translate("QtWidgetsApplication3Class", "QtWidgetsApplication3", nullptr));
        label_2->setText(QCoreApplication::translate("QtWidgetsApplication3Class", "Total Clicked: ", nullptr));
        total_label->setText(QCoreApplication::translate("QtWidgetsApplication3Class", "00", nullptr));
        label->setText(QCoreApplication::translate("QtWidgetsApplication3Class", "Blue:", nullptr));
        blue_label->setText(QCoreApplication::translate("QtWidgetsApplication3Class", "00", nullptr));
        label_4->setText(QCoreApplication::translate("QtWidgetsApplication3Class", "Red :", nullptr));
        red_label->setText(QCoreApplication::translate("QtWidgetsApplication3Class", "00", nullptr));
        pushButton->setText(QCoreApplication::translate("QtWidgetsApplication3Class", "\353\270\224\353\243\250", nullptr));
        pushButton_2->setText(QCoreApplication::translate("QtWidgetsApplication3Class", "\353\240\210\353\223\234", nullptr));
        pushButton_3->setText(QCoreApplication::translate("QtWidgetsApplication3Class", "undo", nullptr));
        pushButton_4->setText(QCoreApplication::translate("QtWidgetsApplication3Class", "\354\264\210\352\270\260\355\231\224", nullptr));
    } // retranslateUi

};

namespace Ui {
    class QtWidgetsApplication3Class: public Ui_QtWidgetsApplication3Class {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_QTWIDGETSAPPLICATION3_H
