#pragma once

#include <QtWidgets/QWidget>
#include "ui_QtWidgetsApplication3.h"

class QtWidgetsApplication3 : public QWidget
{
    Q_OBJECT

public:
    QtWidgetsApplication3(QWidget *parent = Q_NULLPTR);
    int blue_count = 0;
    int red_count = 0;
    int total_count = 0;
    int red_sig;
    int blue_sig;


private:
    Ui::QtWidgetsApplication3Class ui;


public slots:
    void run_btn_1();
    void run_btn_2();
    void run_btn_3();
    void run_btn_reset();

};
